﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Pex4Fun;
using TestRunner;
using System.Reflection;

namespace VerifyMinimizedTests
{
    class VerifyMinimal
    {
        static string currDir = System.IO.Directory.GetParent(Environment.CurrentDirectory).ToString();
        static void Main(string[] args)
        {
            //Navigate from '\Approach\First\Sp18_Q11_10_addToEnd\editedMetaProject\bin' to '\'
            string topDir = Path.GetFullPath(Path.Combine(currDir, @"..\..\..\..\..\"));
            string minimalFailedUniqueDir = topDir + @"Results\SecondLevel\Approach\CompleteEquivalence\Sp18_Q11_10_addToEnd\DefaultFilter\MinimalUniqueClusterTests\Failed";
            string TestRunnerProjectDir = Path.GetFullPath(Path.Combine(currDir, @"..\..\TestRunner"));
            string nonEquivalentSubmissionsDir = Path.GetFullPath(Path.Combine(currDir, @"..\NonequivalentSubmissions\"));
            string assemblyFilePath = Path.GetFullPath(Path.Combine(currDir, @"..\..\TestRunner\bin\Debug\TestRunner.dll"));

            //From Pex4Fun
            string hardcodedMetaProjName = "meta_project1525456207";
            string methodName = "addToEnd";
            string editedMetaProjectDir = Path.GetFullPath(Path.Combine(currDir, @"..\..\editedMetaProject_verify"));


            foreach (var file in Directory.GetFiles(minimalFailedUniqueDir)) //Each file containing set of min tests
            {
                string[] minimalFailingArr = File.ReadAllText(file).Split('}');
                string testName = file.Substring(file.LastIndexOf("\\") + 1);
                for (int j = 0; j < minimalFailingArr.Length - 1; j++) //Each test in file
                {
                    string currTest = minimalFailingArr[j];
                    replaceTestMethodBody(currTest + "}"); //Add back the missing curly brace
                    //Debug
                    Console.WriteLine("CURR TEST BEFORE: " + currTest + "}");

                    foreach (var currSubmission in Directory.GetFiles(nonEquivalentSubmissionsDir)) //Each submission to be tested
                    {
                        string submissionName = currSubmission.Substring(currSubmission.LastIndexOf("\\") + 1); //For printin statement
                        
                        //Copy method body to addToEnd
                        Pex4Fun.FileModifier.CopyBodyToMetaProgram(currSubmission, editedMetaProjectDir, methodName, hardcodedMetaProjName);
                        //Recompile MetaProgram.cs
                        Pex4Fun.BuildDirectory.BuildSingleProject(editedMetaProjectDir, true);
                        //Recompile TestRunner.cs
                        Pex4Fun.BuildDirectory.BuildSingleProject(TestRunnerProjectDir, true);
                        //Run test
                        runTestMethod(assemblyFilePath, new string[] {testName, (j+1).ToString(), submissionName, currDir});
                    }
                }
            }
        }

        static void replaceTestMethodBody(string testMethodBody)
        {
            //Replaces method body in TestRunner's file
            string TestRunnerFilePath = Path.GetFullPath(Path.Combine(currDir, @"..\..\TestRunner\TestRunner.cs"));
            string[] TestRunnerFileArr = File.ReadAllLines(TestRunnerFilePath);
            string TestRunnerFileStr = string.Join("\n", TestRunnerFileArr);
            int startIndx = -1;
            int endIndx = TestRunnerFileStr.IndexOf("}");
            StringBuilder sb = new StringBuilder();

            //Search for matching open curly backwards
            for (int i = endIndx; i > 0; i--)
            {
                if (TestRunnerFileStr[i] == '{')
                {
                    startIndx = i;
                    break;
                }
            }
            TestRunnerFileStr = TestRunnerFileStr.Remove(startIndx, (endIndx - startIndx + 1)); //Deletes curly braces too
            TestRunnerFileStr = TestRunnerFileStr.Insert(startIndx, testMethodBody);
            //Debug
            Console.WriteLine("CURR TEST AFTER: " + TestRunnerFileStr);
            sb.AppendLine(TestRunnerFileStr);
            File.WriteAllText(TestRunnerFilePath, sb.ToString());
        }

        

        //Fetch TestRunner's newest .dll and run its testMethod()
        static void runTestMethod(string assemblyFilePath, String[] args)
        {
            //Load the TestRunner.dll into the current application domain
            Assembly a = Assembly.Load(System.IO.File.ReadAllBytes(assemblyFilePath));
            //Get class name to use
            Type myType = a.GetType("TestRunner.TestRunnerClass");
            //Get the method to call    
            MethodInfo myMethod = myType.GetMethod("helper");
            //Create an instance
            object obj = Activator.CreateInstance(myType, null);
            //Execute testMethod() 
            myMethod.Invoke(obj, new Object[] {args});
        }
    }
}