using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MetaProject;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Pex.Framework;
using System.IO;


namespace TestRunner
{
    public class TestRunnerClass
    {
        public static void testMethod()
        {    MetaProgram.List list;    MetaProgram.List list1;    int[] ints = new int[1];    list = MetaProgramFactory.CreateList(ints);    int[] ints1 = new int[1];    list1 = MetaProgramFactory.CreateList(ints1);    MetaProgram.Check(list1, list, 0);}


        public static void Main()
        {
            //Main method never called. Does nothing.
            testMethod();
        }

        public static void helper(Object[] args)
        {
            string testName = (string) args[0];
            string i = (string) args[1];
            string submissionName = (string) args[2];
            string currDir = (string) args[3];

            try
            {
                testMethod();
            }
            catch (OverflowException e)
            {
                Console.WriteLine(e.Message);
                string stringToPrint = testName + "'s test #" + i + " killed " + submissionName;
                Console.WriteLine(stringToPrint);
                //Record submissions that each test killed
                printResultToFile(currDir, stringToPrint);
                Console.WriteLine("-----------------------------------------------------------");
            }
            catch (Microsoft.Pex.Framework.Exceptions.PexAssumeFailedException e)
            {
                Console.WriteLine(e.Message);
                string stringToPrint = testName + "'s test #" + i + " was INVALID!";
                Console.WriteLine(stringToPrint);
                //Record submissions that each test killed
                printResultToFile(currDir, stringToPrint);
                Console.WriteLine("-----------------------------------------------------------");
            }
        }

        static void printResultToFile(string currDir, string stringToPrint)
        {
            string path = Path.GetFullPath(Path.Combine(currDir, @"..\Killed.txt"));
            if (!File.Exists(path))
            {
                File.Create(path).Dispose();
                using (TextWriter tw = new StreamWriter(path))
                {
                    tw.WriteLine(stringToPrint);
                }
            }
            else if (File.Exists(path))
            {
                using (TextWriter tw = new StreamWriter(path, true))
                {
                    tw.WriteLine(stringToPrint);
                }
            }
        }
        
    }
}
