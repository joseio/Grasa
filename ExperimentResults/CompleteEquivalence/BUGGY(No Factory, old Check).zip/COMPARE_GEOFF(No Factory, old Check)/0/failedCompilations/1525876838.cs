using System;

/// <summary>Class for representing a linked list of ints.</summary>
public class List
{
	public int value;

	public List next;

	public List()
	{
	}

	public List(int setValue)
	{
		value = setValue;
	}

	/// <summary>Add a value as the last item in the list.</summary>
	/// <remarks>
	/// Add a value as the last item in the list.
	/// Can be called on any item of the list, although will normally be called
	/// on the first item.
	/// </remarks>
	public virtual void addToEnd(int newValue)
	{
		System.Console.Out.println();
		System.Console.Out.println("newValue: " + newValue);
		List currentNode = this;
		System.Console.Out.println("this: " + currentNode.value);
		while (currentNode.next != null)
		{
			System.Console.Out.println("next: " + currentNode.next.value);
			currentNode = currentNode.next;
		}
		currentNode.next = new List(newValue);
	}
}
